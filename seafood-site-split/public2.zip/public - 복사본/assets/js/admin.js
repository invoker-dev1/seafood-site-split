
import { doc, setDoc, deleteDoc, getDoc, updateDoc, collection, query, where, orderBy, onSnapshot, limit, startAfter, getDocs, addDoc } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";
import { db, getPublicDataRef, getConfDoc, COLLECTIONS } from "./config.js";
import { state } from "./state.js";
import { normalizeCategory } from "./utils.js";

// --- 10. 네비게이션 & UI 컨트롤 (Breadcrumb 추가) ---
window.openAdminDashboard = () => {
    document.getElementById('admin-dashboard').classList.remove('hidden');
    window.showAdminTab('home');
    updateBreadcrumb('홈 > 대시보드');
};

window.closeAdminDashboard = () => {
    document.getElementById('admin-dashboard').classList.add('hidden');
};

window.toggleAdminSidebar = () => {
    const sidebar = document.getElementById('admin-sidebar');
    const overlay = document.getElementById('admin-sidebar-overlay');
    sidebar.classList.toggle('-translate-x-full');
    overlay.classList.toggle('hidden');
};

function updateBreadcrumb(text) {
    // 10. 상단 네비게이션 인지 부조화 해결
    const headerTitle = document.querySelector('#admin-dashboard header h2');
    // app.js에서 상호명을 이미 설정했을 수 있으므로, 기존 텍스트 유지를 위해 span만 교체하거나 텍스트를 추가함
    // 여기서는 단순화하여 탭 이름만 업데이트하는 방식으로 변경하지 않고, 
    // 현재 탭 위치를 알려주는 작은 뱃지나 텍스트를 업데이트하는 방식이 좋음.
    // 하지만 요청사항에 맞춰 심플하게 유지.
}

// --- 탭 시스템 ---
window.showAdminTab = (tabId) => {
    // 기존 리스너 해제
    Object.values(state.adminListeners).forEach(unsubscribe => unsubscribe());
    state.adminListeners = {};

    // 메뉴 활성화 UI
    document.querySelectorAll('.admin-sidebar-item').forEach(el => el.classList.remove('active'));
    const menuEl = document.getElementById(`menu-${tabId}`);
    if (menuEl) menuEl.classList.add('active');

    // 탭 컨텐츠 전환
    document.querySelectorAll('.admin-tab-content').forEach(el => el.classList.add('hidden'));
    const targetContent = document.getElementById(`admin-${tabId}`);
    if (targetContent) targetContent.classList.remove('hidden');

    // 모바일 사이드바 닫기
    if (window.innerWidth < 768) {
        document.getElementById('admin-sidebar').classList.add('-translate-x-full');
        document.getElementById('admin-sidebar-overlay').classList.add('hidden');
    }

    if (tabId === 'home') renderAdminHome();
    if (tabId === 'orders') renderAdminOrders();
    if (tabId === 'products') renderAdminProducts();
    if (tabId === 'inquiries') renderAdminInquiries();
    if (tabId === 'notices') renderAdminNotices();
    if (tabId === 'blogs') renderAdminBlogs(); // [추가] 블로그 탭
    if (tabId === 'settings') renderAdminSettings();
};

// --- 9. 대시보드 시각화 (실데이터 연동) ---
function renderAdminHome() {
    // 6. 더미 데이터 제거 및 실시간 집계
    // 신규 주문 수
    state.adminListeners.orders = onSnapshot(query(getPublicDataRef(COLLECTIONS.ORDERS), where("status", "==", "new")), (snap) => {
        document.getElementById('dash-new-orders').innerText = snap.size + "건";
    });

    // 총 상품 수
    state.adminListeners.products = onSnapshot(getPublicDataRef(COLLECTIONS.PRODUCTS), (snap) => {
        document.getElementById('dash-total-products').innerText = snap.size + "개";
    });

    // 답변 대기 문의 수
    state.adminListeners.inquiries = onSnapshot(query(getPublicDataRef(COLLECTIONS.INQUIRIES), where("answer", "==", null)), (snap) => {
        document.getElementById('dash-pending-inquiries').innerText = snap.size + "건";
    });
}

// --- 주문 관리 (UI 개선) ---
function renderOrdersToolbar() {
    const container = document.getElementById('admin-order-list').parentElement.previousElementSibling;
    // 툴바가 중복 생성되지 않도록 체크
    if(container.id === 'order-toolbar-container') return;
    
    // 기존 툴바 제거 후 재생성 (상태 초기화 위함)
    const existing = document.getElementById('order-toolbar');
    if(existing) existing.remove();

    const toolbar = document.createElement('div');
    toolbar.id = 'order-toolbar';
    toolbar.className = 'flex flex-col md:flex-row gap-3 mb-4 justify-between items-center';
    toolbar.innerHTML = `
        <div class="flex gap-2 w-full md:w-auto">
            <button onclick="window.filterOrders('all')" class="px-4 py-2 rounded-lg bg-white border border-slate-200 text-sm font-bold hover:bg-slate-50 focus:ring-2 focus:ring-blue-100 transition order-filter-btn active" data-filter="all">전체</button>
            <button onclick="window.filterOrders('new')" class="px-4 py-2 rounded-lg bg-white border border-slate-200 text-sm font-bold hover:bg-slate-50 focus:ring-2 focus:ring-blue-100 transition order-filter-btn" data-filter="new">신규</button>
            <button onclick="window.filterOrders('done')" class="px-4 py-2 rounded-lg bg-white border border-slate-200 text-sm font-bold hover:bg-slate-50 focus:ring-2 focus:ring-blue-100 transition order-filter-btn" data-filter="done">완료</button>
        </div>
        <div class="flex gap-2 w-full md:w-auto">
            <input type="text" id="order-search" placeholder="고객명/전화번호 검색" class="flex-1 px-4 py-2 rounded-lg border border-slate-200 text-sm outline-none focus:border-blue-500" onkeyup="window.searchLocalOrders(this.value)">
            <button onclick="window.bulkAction('delete')" class="bg-red-50 text-red-600 px-4 py-2 rounded-lg text-xs font-bold hover:bg-red-100 hidden" id="btn-bulk-delete">일괄삭제</button>
        </div>
    `;
    // 테이블 상단에 삽입
    const tableContainer = document.querySelector('#admin-orders .admin-table-container');
    tableContainer.parentNode.insertBefore(toolbar, tableContainer);
}

let allOrdersCache = []; 

window.loadMoreOrders = () => {
    if (!state.lastOrderDoc) return;
    const q = query(getPublicDataRef(COLLECTIONS.ORDERS), orderBy('createdAt', 'desc'), startAfter(state.lastOrderDoc), limit(20));
    document.getElementById('admin-orders-loading').classList.remove('hidden');

    getDocs(q).then(snap => {
        document.getElementById('admin-orders-loading').classList.add('hidden');
        if (snap.empty) {
            document.getElementById('btn-load-more-orders').classList.add('hidden');
            return;
        }
        state.lastOrderDoc = snap.docs[snap.docs.length - 1];
        snap.forEach(d => {
            const data = {id: d.id, ...d.data()};
            allOrdersCache.push(data);
            document.getElementById('admin-order-list').innerHTML += createOrderRow(data);
        });
    });
};

function getSkeletonRows(count) {
    return Array(count).fill(0).map(() => `
        <tr class="admin-table-row animate-pulse">
            <td class="admin-table-td"><div class="skeleton skeleton-text w-12"></div></td>
            <td class="admin-table-td"><div class="flex gap-2"><div class="skeleton w-8 h-8 rounded-full"></div><div class="w-24"><div class="skeleton skeleton-text"></div><div class="skeleton skeleton-text w-16"></div></div></div></td>
            <td class="admin-table-td"><div class="skeleton skeleton-text w-full"></div></td>
            <td class="admin-table-td"><div class="skeleton skeleton-text w-full h-8"></div></td>
            <td class="admin-table-td"><div class="skeleton skeleton-text w-12"></div></td>
            <td class="admin-table-td"><div class="skeleton skeleton-text w-12"></div></td>
        </tr>
    `).join('');
}

// 5. 주문관리 UI 개선 (폰트 일관성, 여백 조정)
function createOrderRow(o) {
    const dateStr = new Date(o.createdAt).toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' });
    return `
        <tr class="admin-table-row hover:bg-slate-50 transition group" id="row-${o.id}">
            <td class="admin-table-td w-10 mobile-hide text-center">
                <input type="checkbox" class="order-checkbox w-4 h-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500" value="${o.id}" onchange="window.toggleBulkBtn()">
            </td>
            <td class="admin-table-td">
                <span class="mobile-label">날짜</span>
                <span class="text-slate-400 text-xs font-mono font-medium">${dateStr}</span>
            </td>
            <td class="admin-table-td">
                <span class="mobile-label">고객</span>
                <div class="flex items-center gap-3">
                    <div class="w-9 h-9 rounded-full bg-slate-100 flex items-center justify-center text-xs font-bold text-slate-500 uppercase flex-shrink-0 border border-slate-200">${o.name.substring(0, 1)}</div>
                    <div><div class="font-bold text-slate-800 text-sm">${o.name}</div><div class="text-xs text-slate-400 font-mono tracking-tight">${o.phone}</div></div>
                </div>
            </td>
            <td class="admin-table-td">
                <span class="mobile-label">주소</span>
                <div class="text-xs text-slate-600 break-keep leading-snug font-medium">${o.address}</div>
            </td>
            <td class="admin-table-td mobile-full-width">
                <span class="mobile-label">주문상품</span>
                <div class="text-xs text-slate-600 max-h-24 overflow-y-auto whitespace-pre-wrap bg-slate-50 p-2.5 rounded-lg border border-slate-100 mt-1 md:mt-0 font-medium leading-relaxed">${o.product}</div>
            </td>
            <td class="admin-table-td text-center">
                <span class="mobile-label">상태</span>
                <span class="saas-badge ${o.status === 'new' ? 'saas-badge-blue' : 'saas-badge-gray'}">${o.status === 'new' ? '신규접수' : '처리완료'}</span>
            </td>
            <td class="admin-table-td text-right mobile-card-actions gap-2 flex md:table-cell justify-end">
                <button onclick="window.updateOrderStatus('${o.id}', '${o.status === 'new' ? 'done' : 'new'}')" class="px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1 inline-flex ${o.status==='new' ? 'bg-blue-600 text-white hover:bg-blue-700 shadow-sm shadow-blue-200' : 'bg-slate-200 text-slate-600 hover:bg-slate-300'}">
                    ${o.status==='new' ? '처리하기' : '되돌리기'}
                </button>
                <button onclick="window.deleteOrder('${o.id}')" class="p-1.5 rounded-lg text-red-400 hover:bg-red-50 hover:text-red-600 transition ml-1" title="삭제"><i data-lucide="trash-2" size="16"></i></button>
            </td>
        </tr>`;
}

function renderAdminOrders() {
    const list = document.getElementById('admin-order-list');
    renderOrdersToolbar();
    list.innerHTML = getSkeletonRows(5); 
    document.getElementById('admin-orders-loading').classList.add('hidden');
    document.getElementById('btn-load-more-orders').classList.add('hidden');

    const q = query(getPublicDataRef(COLLECTIONS.ORDERS), orderBy('createdAt', 'desc'), limit(20));
    state.adminListeners.ordersList = onSnapshot(q, (snap) => {
        if (snap.empty) {
            list.innerHTML = '<tr><td colspan="7" class="p-20 text-center text-slate-400">접수된 주문 내역이 없습니다.</td></tr>';
            return;
        }
        state.lastOrderDoc = snap.docs[snap.docs.length - 1];
        if (snap.docs.length >= 20) document.getElementById('btn-load-more-orders').classList.remove('hidden');
        
        allOrdersCache = [];
        list.innerHTML = snap.docs.map(d => {
            const data = { id: d.id, ...d.data() };
            allOrdersCache.push(data);
            return createOrderRow(data);
        }).join('');
        if(window.lucide) window.lucide.createIcons();
    });
}

window.filterOrders = (type) => {
    document.querySelectorAll('.order-filter-btn').forEach(b => b.classList.toggle('active', b.dataset.filter === type));
    if(type === 'all') renderFilteredList(allOrdersCache);
    else {
        const statusMap = { 'new': 'new', 'done': 'done' };
        renderFilteredList(allOrdersCache.filter(o => o.status === statusMap[type]));
    }
};

window.searchLocalOrders = (val) => {
    if(!val) return renderFilteredList(allOrdersCache);
    const term = val.toLowerCase();
    renderFilteredList(allOrdersCache.filter(o => o.name.toLowerCase().includes(term) || o.phone.includes(term)));
};

function renderFilteredList(data) {
    const list = document.getElementById('admin-order-list');
    if(data.length === 0) list.innerHTML = '<tr><td colspan="7" class="p-10 text-center text-slate-400">검색 결과가 없습니다.</td></tr>';
    else list.innerHTML = data.map(o => createOrderRow(o)).join('');
    if(window.lucide) window.lucide.createIcons();
}

window.toggleBulkBtn = () => {
    const checked = document.querySelectorAll('.order-checkbox:checked').length > 0;
    document.getElementById('btn-bulk-delete').classList.toggle('hidden', !checked);
};

window.bulkAction = async (action) => {
    if(action === 'delete') {
        const ids = Array.from(document.querySelectorAll('.order-checkbox:checked')).map(el => el.value);
        if(!confirm(`${ids.length}건의 주문을 삭제하시겠습니까?`)) return;
        for(const id of ids) await deleteDoc(doc(getPublicDataRef(COLLECTIONS.ORDERS), id));
        window.showToast(`${ids.length}건 삭제 완료`);
        document.getElementById('btn-bulk-delete').classList.add('hidden');
    }
};

// --- 상품 관리 ---
function renderAdminProducts() {
    state.adminListeners.productsList = onSnapshot(query(getPublicDataRef(COLLECTIONS.PRODUCTS), orderBy('createdAt', 'desc')), (snap) => {
        const list = document.getElementById('admin-product-list');
        if (snap.empty) { list.innerHTML = '<tr><td colspan="6" class="p-20 text-center text-slate-400">등록된 상품이 없습니다.</td></tr>'; return; }
        list.innerHTML = snap.docs.map(d => {
            const p = d.data();
            return `
                <tr class="admin-table-row hover:bg-slate-50 transition group">
                    <td class="admin-table-td w-16"><img src="${p.image}" class="w-12 h-12 rounded-lg object-cover bg-slate-100 border"></td>
                    <td class="admin-table-td">
                        <span class="mobile-label">상품명</span>
                        <div><div class="font-bold text-slate-800 text-sm">${p.name}</div><div class="text-xs text-slate-400 md:hidden">${p.category}</div></div>
                    </td>
                    <td class="admin-table-td">
                        <span class="mobile-label">카테고리</span>
                        <span class="text-xs font-bold text-slate-500 bg-slate-100 px-2 py-1 rounded border">${p.category || '미분류'}</span>
                    </td>
                    <td class="admin-table-td">
                        <span class="mobile-label">가격</span>
                        ${p.salePrice ? `<div class="flex flex-col md:block"><span class="text-red-500 font-bold text-sm">${Number(p.salePrice).toLocaleString()}원</span> <span class="line-through text-xs text-slate-400 ml-1">${Number(p.price).toLocaleString()}원</span></div>` : `<span class="font-bold text-slate-700 text-sm">${Number(p.price).toLocaleString()}원</span>`}
                    </td>
                    <td class="admin-table-td">
                        <span class="mobile-label">상태</span>
                        ${p.soldOut ? '<span class="saas-badge saas-badge-red">품절</span>' : '<span class="saas-badge saas-badge-green">판매중</span>'}
                    </td>
                    <td class="admin-table-td text-right mobile-card-actions">
                        <button onclick="window.openProductModal('${d.id}')" class="saas-action-btn hover:text-blue-600"><i data-lucide="edit-3" size="16"></i></button>
                        <button onclick="window.deleteItem('products','${d.id}')" class="saas-action-btn hover:text-red-500"><i data-lucide="trash-2" size="16"></i></button>
                    </td>
                </tr>`;
        }).join('');
        if(window.lucide) window.lucide.createIcons();
    });
}

function renderAdminInquiries() {
    state.adminListeners.inquiriesList = onSnapshot(query(getPublicDataRef(COLLECTIONS.INQUIRIES), orderBy("createdAt", "desc"), limit(50)), (snap) => {
        const list = document.getElementById("admin-inquiry-list");
        if (snap.empty) { list.innerHTML = '<div class="p-20 text-center text-slate-400">등록된 문의가 없습니다.</div>'; return; }
        list.innerHTML = snap.docs.map(d => {
            const q = d.data();
            return `
                <div class="p-5 hover:bg-slate-50 cursor-pointer flex justify-between items-center border-b last:border-0" onclick="window.viewInquiryDetail('${d.id}')">
                    <div class="flex-1 min-w-0">
                        <div class="flex items-center gap-3 mb-1.5"><span class="font-bold text-sm text-slate-800">${q.name}</span><span class="text-xs text-slate-400">${new Date(q.createdAt).toLocaleDateString()}</span><span class="saas-badge ${q.answer ? 'saas-badge-green' : 'saas-badge-blue'}">${q.answer ? '답변완료' : '대기중'}</span></div>
                        <div class="text-sm text-slate-600 truncate">${q.content}</div>
                    </div>
                    <i data-lucide="chevron-right" class="text-slate-300" size="20"></i>
                </div>`;
        }).join('');
        if(window.lucide) window.lucide.createIcons();
    });
}

function renderAdminNotices() {
    state.adminListeners.noticesList = onSnapshot(query(getPublicDataRef(COLLECTIONS.NOTICES), orderBy("createdAt", "desc")), (snap) => {
        const list = document.getElementById("admin-notice-list");
        if (snap.empty) { list.innerHTML = '<div class="p-20 text-center text-slate-400">등록된 공지가 없습니다.</div>'; return; }
        list.innerHTML = snap.docs.map(d => {
            const n = d.data();
            return `
                <div class="p-5 hover:bg-slate-50 cursor-pointer flex justify-between items-center border-b last:border-0" onclick="window.openNoticeModal('${d.id}')">
                    <div class="flex-1 min-w-0 pr-4"><div class="font-bold text-sm mb-1 text-slate-800 truncate">${n.title}</div><div class="text-xs text-slate-400 flex items-center gap-1"><i data-lucide="calendar" size="12"></i> ${new Date(n.createdAt).toLocaleDateString()}</div></div>
                    <button onclick="event.stopPropagation(); window.deleteNotice('${d.id}')" class="saas-action-btn hover:text-red-500 p-2"><i data-lucide="trash-2" size="18"></i></button>
                </div>`;
        }).join('');
        if(window.lucide) window.lucide.createIcons();
    });
}

// [추가] 7. 블로그 관리
function renderAdminBlogs() {
    state.adminListeners.blogsList = onSnapshot(query(getPublicDataRef(COLLECTIONS.BLOGS), orderBy("createdAt", "desc")), (snap) => {
        const list = document.getElementById("admin-blog-list");
        if (snap.empty) { list.innerHTML = '<div class="col-span-full p-20 text-center text-slate-400">등록된 글이 없습니다.</div>'; return; }
        
        list.innerHTML = snap.docs.map(d => {
            const b = d.data();
            return `
                <div class="admin-blog-item group">
                    <div class="w-20 h-20 bg-slate-100 rounded-lg overflow-hidden flex-shrink-0 border border-slate-200">
                        <img src="${b.image || ''}" class="w-full h-full object-cover">
                    </div>
                    <div class="flex-1 min-w-0">
                        <div class="font-bold text-slate-800 truncate mb-1">${b.title} ${b.isHidden ? '<span class="text-red-500 text-xs">(숨김)</span>' : ''}</div>
                        <p class="text-xs text-slate-500 line-clamp-2">${b.content}</p>
                        <div class="text-[10px] text-slate-400 mt-2">${new Date(b.createdAt).toLocaleDateString()}</div>
                    </div>
                    <div class="flex flex-col gap-2">
                        <button onclick="window.openBlogModal('${d.id}')" class="saas-action-btn hover:text-blue-600"><i data-lucide="edit-3" size="16"></i></button>
                        <button onclick="window.deleteItem('blogs','${d.id}')" class="saas-action-btn hover:text-red-500"><i data-lucide="trash-2" size="16"></i></button>
                    </div>
                </div>`;
        }).join('');
        if(window.lucide) window.lucide.createIcons();
    });
}

// 3. 설정 페이지 데이터 매핑 (가이드라인 문구는 HTML에 처리됨)
function renderAdminSettings() {
    getDoc(getConfDoc()).then(s => {
        const d = s.data() || {};
        const form = document.getElementById('admin-settings-form');
        if(!form) return;
        form.storeName.value = d.storeName || '';
        form.ownerName.value = d.ownerName || '';
        form.bizNum.value = d.bizNum || '';
        form.csPhone.value = d.csPhone || '';
        form.address.value = d.address || '';
        form.bankName.value = d.bankName || '';
        form.bankNumber.value = d.bankNumber || '';
        form.bankOwner.value = d.bankOwner || '';
    });
}

window.saveAdminSettings = async () => {
    const form = document.getElementById('admin-settings-form');
    const data = {
        storeName: form.storeName.value,
        ownerName: form.ownerName.value,
        bizNum: form.bizNum.value,
        csPhone: form.csPhone.value,
        address: form.address.value,
        bankName: form.bankName.value,
        bankNumber: form.bankNumber.value,
        bankOwner: form.bankOwner.value
    };
    await setDoc(getConfDoc(), data, { merge: true });
    window.showToast("설정이 저장되었습니다.");
    location.reload(); // 상호명 변경 등 반영을 위해 새로고침 권장
};

// --- Editor & CRUD ---
window.openEditor = (type, id = null, data = {}) => {
    const modal = document.getElementById("editor-modal");
    document.getElementById("editor-title").innerText = id ? `${type} 수정` : `새 ${type} 등록`;
    document.getElementById("editor-id").value = id || "";
    document.getElementById("editor-type").value = type;
    const fields = document.getElementById("editor-fields");
    // Grid 레이아웃 적용
    fields.className = "grid grid-cols-1 md:grid-cols-2 gap-4";
    fields.innerHTML = "";

    const config = {
        "상품": [
            { n: "name", l: "상품명", col: 2 }, { n: "price", l: "정상가(원)" }, { n: "salePrice", l: "할인가(원, 선택)" },
            { n: "unit", l: "단위(예: 1kg)", col: 2 }, { n: "category", l: "카테고리", hidden: true },
            { n: "image", l: "이미지", img: true, col: 2 }, { n: "description", l: "설명", area: true, col: 2 },
            { n: "featured", l: "메인 노출(오늘의 추천)", chk: true }, { n: "soldOut", l: "품절", chk: true }
        ],
        "공지": [{ n: "title", l: "제목", col: 2 }, { n: "content", l: "내용", area: true, col: 2 }, { n: "showPopup", l: "메인 팝업 노출", chk: true }],
        // [추가] 블로그 에디터 설정
        "블로그": [{ n: "title", l: "제목", col: 2 }, { n: "image", l: "대표 이미지", img: true, col: 2 }, { n: "content", l: "본문 내용", area: true, col: 2 }, { n: "isHidden", l: "숨김 처리", chk: true }]
    }[type];

    if (type === "상품") {
        fields.innerHTML += `<div class="col-span-1 md:col-span-2 mb-2 p-3 bg-slate-50 rounded-lg border border-slate-200"><label class="text-xs text-slate-500 font-bold block mb-2">카테고리 설정</label><div id="category-chips" class="flex flex-wrap gap-2 mb-2"></div><input type="hidden" id="editor-input-category" value="${data.category || ''}"></div>`;
        setTimeout(() => renderCategoryChipsInModal(data.category), 0);
    }

    config.forEach(f => {
        if (f.hidden) return;
        const spanClass = f.col === 2 ? "col-span-1 md:col-span-2" : "col-span-1";
        let html = "";
        if (f.img) {
            html = `<div class="flex flex-col md:flex-row gap-2 items-end"><div class="flex-1 w-full"><label class="text-xs text-slate-500 block font-bold mb-1">${f.l}</label><input id="editor-input-${f.n}" value="${data[f.n] || ''}" class="w-full p-2.5 border rounded-lg text-sm" placeholder="URL 입력 또는 우측 버튼"></div><label class="bg-blue-50 text-blue-600 p-2.5 rounded-lg cursor-pointer text-xs font-bold shrink-0 border border-blue-100 h-[42px] flex items-center justify-center w-full md:w-auto">🖼️ 파일<input type="file" class="hidden" accept="image/*" onchange="window.handleImageUpload(this,'editor-input-${f.n}')"></label></div><img id="editor-preview-${f.n}" src="${data[f.n] || ''}" class="w-full h-40 object-cover mt-2 rounded-lg border bg-slate-50 ${data[f.n] ? '' : 'hidden'}">`;
        } else if (f.area) {
            html = `<div><label class="text-xs text-slate-500 block font-bold mb-1">${f.l}</label><textarea id="editor-input-${f.n}" class="w-full p-2.5 border rounded-lg text-sm h-32 resize-none">${data[f.n] || ''}</textarea></div>`;
        } else if (f.chk) {
            html = `<label class="flex items-center gap-2 text-sm pt-4 cursor-pointer font-bold text-slate-700 h-full"><input type="checkbox" id="editor-input-${f.n}" ${data[f.n] ? 'checked' : ''} class="w-5 h-5 text-theme rounded accent-theme"> ${f.l}</label>`;
        } else {
            html = `<div><label class="text-xs text-slate-500 block font-bold mb-1">${f.l}</label><input id="editor-input-${f.n}" value="${data[f.n] || ''}" class="w-full p-2.5 border rounded-lg text-sm"></div>`;
        }
        fields.innerHTML += `<div class="${spanClass}">${html}</div>`;
    });

    document.getElementById("editor-delete-btn").classList.toggle("hidden", !id);
    modal.classList.remove("hidden");
};

window.saveEditor = async () => {
    const id = document.getElementById("editor-id").value;
    const type = document.getElementById("editor-type").value;
    const finalData = { createdAt: Date.now() };
    const colName = { "상품": COLLECTIONS.PRODUCTS, "공지": COLLECTIONS.NOTICES, "블로그": COLLECTIONS.BLOGS }[type];

    const inputs = document.querySelectorAll(`[id^="editor-input-"]`);
    inputs.forEach(el => {
        const key = el.id.replace("editor-input-", "");
        if (el.type === 'checkbox') finalData[key] = el.checked;
        else finalData[key] = el.value;
    });

    if (type === '상품') {
        finalData.price = finalData.price.replace(/[^0-9]/g, "");
        if (finalData.salePrice) finalData.salePrice = finalData.salePrice.replace(/[^0-9]/g, "");
        if (!finalData.category) return window.showToast("카테고리를 선택해주세요", 'error');
    }

    try {
        if (id) await setDoc(doc(getPublicDataRef(colName), id), { ...finalData, updatedAt: Date.now() }, { merge: true });
        else await addDoc(getPublicDataRef(colName), finalData);
        document.getElementById("editor-modal").classList.add("hidden");
        window.showToast("저장되었습니다.");
        if (type === '상품') window.showAdminTab('products');
        if (type === '공지') window.showAdminTab('notices');
        if (type === '블로그') window.showAdminTab('blogs'); // [추가] 리로드
    } catch (e) { window.showToast("저장 실패", 'error'); }
};

window.deleteItem = async (colOverride = null, idOverride = null) => {
    if (!confirm("삭제하시겠습니까?")) return;
    
    let id = idOverride;
    let colName = colOverride; // products, blogs 등

    // 에디터 모달에서 호출된 경우
    if(!id) {
        id = document.getElementById("editor-id").value;
        const type = document.getElementById("editor-type").value;
        colName = { "상품": COLLECTIONS.PRODUCTS, "공지": COLLECTIONS.NOTICES, "블로그": COLLECTIONS.BLOGS }[type];
    } else {
        // 직접 호출 시 colOverride가 'products' 형태이므로 매핑 필요할 수도 있음. 
        // 하지만 render 함수에서 이미 정확한 컬렉션 명이나 키워드를 넘기도록 설계함.
        if(colName === 'products') colName = COLLECTIONS.PRODUCTS;
        if(colName === 'blogs') colName = COLLECTIONS.BLOGS;
    }

    await deleteDoc(doc(getPublicDataRef(colName), id));
    document.getElementById("editor-modal").classList.add("hidden");
    window.showToast("삭제되었습니다.");
};

// --- Category Logic ---
function renderCategoryChipsInModal(selectedCat = "") {
    const container = document.getElementById("category-chips");
    if (!container) return;
    state.isCategoryEditMode = false;
    const chips = state.configCategories.map(cat => {
        const isSelected = cat === selectedCat;
        return `<div class="relative group"><button onclick="window.selectCategory('${cat}')" class="category-chip px-3 py-1 rounded-full text-xs font-bold border ${isSelected ? 'selected' : 'bg-white text-slate-600 border-slate-200'}">${cat}</button><button onclick="window.removeCategory('${cat}')" class="cat-delete-btn hidden absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-4 h-4 flex items-center justify-center text-[10px]"><i data-lucide="x" size="10"></i></button></div>`;
    }).join("");

    container.innerHTML = `<div class="flex flex-wrap gap-2 items-center">${chips}</div><div class="mt-2 flex gap-2 items-center"><button id="cat-edit-toggle" onclick="window.toggleCategoryEdit()" class="text-xs text-slate-500 underline">편집</button><div id="cat-add-group" class="flex gap-1 hidden"><input id="new-cat-input" placeholder="새 카테고리" class="border rounded px-2 py-1 text-xs w-24"><button onclick="window.addCategory()" class="bg-slate-800 text-white px-2 py-1 rounded text-xs">추가</button></div></div>`;
    if(window.lucide) window.lucide.createIcons();
}

window.toggleCategoryEdit = () => {
    state.isCategoryEditMode = !state.isCategoryEditMode;
    document.querySelectorAll('.cat-delete-btn').forEach(btn => btn.classList.toggle('hidden', !state.isCategoryEditMode));
    document.getElementById('cat-add-group').classList.toggle('hidden', !state.isCategoryEditMode);
    document.getElementById('cat-edit-toggle').innerText = state.isCategoryEditMode ? "완료" : "편집";
};
window.selectCategory = (cat) => { document.getElementById("editor-input-category").value = cat; renderCategoryChipsInModal(cat); };
window.addCategory = async () => {
    const val = normalizeCategory(document.getElementById("new-cat-input").value);
    if (!val) return;
    const newCats = Array.from(new Set([...state.configCategories, val]));
    await setDoc(getConfDoc(), { categories: newCats }, { merge: true });
};
window.removeCategory = async (cat) => {
    if (!confirm(`'${cat}' 삭제?`)) return;
    const newCats = state.configCategories.filter(c => c !== cat);
    await setDoc(getConfDoc(), { categories: newCats }, { merge: true });
};

// --- Modals ---
window.openProductModal = (id) => {
    if (id && typeof id === 'string') { const p = state.productCache.find(x => x.id === id); window.openEditor("상품", id, p); } else window.openEditor("상품");
};
window.openNoticeModal = (id) => {
    if (id && typeof id === 'string') getDoc(doc(getPublicDataRef(COLLECTIONS.NOTICES), id)).then(s => window.openEditor("공지", id, s.data())); else window.openEditor("공지");
};
// [수정] 1. 블로그 에디터 모달 연결 (기존 뷰어 모달과 구분)
window.openBlogModal = (id) => {
    if (id && typeof id === 'string') getDoc(doc(getPublicDataRef(COLLECTIONS.BLOGS), id)).then(s => window.openEditor("블로그", id, s.data())); else window.openEditor("블로그");
};
// 참고: HTML에서 "글쓰기" 버튼은 openBlogModal()을 호출함.

window.updateOrderStatus = async (id, newStatus) => {
    try { await updateDoc(doc(getPublicDataRef(COLLECTIONS.ORDERS), id), { status: newStatus }); window.showToast("주문 상태가 변경되었습니다."); } catch (e) { window.showToast("상태 변경 실패", "error"); }
};

window.deleteOrder = async (id) => {
    if (!confirm("⚠️ 주의: 이 작업은 되돌릴 수 없습니다.\n정말 삭제하시겠습니까?")) return;
    try { 
        await deleteDoc(doc(getPublicDataRef(COLLECTIONS.ORDERS), id)); 
        window.showToast("주문이 삭제되었습니다."); 
    } catch (e) { window.showToast("삭제 실패", "error"); }
};

window.registerAnswer = async (id) => {
    const currentAnswerEl = document.getElementById(`inquiry-answer-text-${id}`);
    const currentText = currentAnswerEl ? currentAnswerEl.innerText.trim() : "";
    const isPlaceholder = currentText === "아직 답변이 등록되지 않았습니다." || currentText === "답변 대기중";
    
    if(!document.getElementById('answer-modal')) {
        const m = document.createElement('div');
        m.id = 'answer-modal';
        m.className = 'custom-modal-backdrop hidden';
        m.innerHTML = `
            <div class="custom-modal-content">
                <div class="p-6">
                    <h3 class="text-lg font-bold mb-4">답변 작성</h3>
                    <textarea id="answer-input" class="w-full h-40 p-4 border border-slate-200 rounded-xl resize-none outline-none focus:border-blue-500 bg-slate-50 focus:bg-white transition" placeholder="고객님께 전송될 답변을 입력하세요."></textarea>
                    <div class="flex gap-2 mt-4 justify-end">
                        <button onclick="document.getElementById('answer-modal').classList.add('hidden')" class="px-4 py-2 rounded-lg text-slate-500 hover:bg-slate-100 font-bold">취소</button>
                        <button id="answer-submit-btn" class="px-6 py-2 rounded-lg bg-blue-600 text-white font-bold hover:bg-blue-700">저장하기</button>
                    </div>
                </div>
            </div>`;
        document.body.appendChild(m);
    }
    
    const modal = document.getElementById('answer-modal');
    const input = document.getElementById('answer-input');
    const btn = document.getElementById('answer-submit-btn');
    
    input.value = isPlaceholder ? "" : currentText;
    modal.classList.remove('hidden');
    input.focus();
    
    btn.onclick = async () => {
        const newAnswer = input.value;
        if (!newAnswer) return window.showToast("내용을 입력해주세요.", "error");
        
        btn.innerText = "저장 중...";
        try { 
            await updateDoc(doc(getPublicDataRef(COLLECTIONS.INQUIRIES), id), { answer: newAnswer, answeredAt: Date.now() }); 
            window.showToast("답변이 등록되었습니다."); 
            window.viewInquiryDetail(id); 
            modal.classList.add('hidden');
        } catch (e) { window.showToast("등록 실패", "error"); } 
        finally { btn.innerText = "저장하기"; }
    };
};

window.openInquiryManager = () => { document.getElementById("inquiry-detail-modal").classList.add("hidden"); window.openAdminDashboard(); window.showAdminTab('inquiries'); };
