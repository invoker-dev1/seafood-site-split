// 앱 전체에서 공유되는 상태 변수들
export const state = {
    isAdmin: false,
    isDesignMode: false,
    currentCart: [],
    configCategories: [],
    productCache: [],
    menuFilterCategory: "all",
    currentBlogId: null,
    orderCache: [],
    isCategoryEditMode: false,
    visibleMenuCount: 20,
    adminListeners: {}, // 리스너 관리
    lastOrderDoc: null  // 페이지네이션용
};