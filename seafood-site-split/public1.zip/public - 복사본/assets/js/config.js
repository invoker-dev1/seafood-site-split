import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-auth.js";
import { getFirestore, collection, doc } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";
import { getStorage } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-storage.js";

export const ADMIN_UID = "7OXzH2aIFZYH9jdJF23GuRdXMy63";
const firebaseConfig = { apiKey: "AIzaSyCPGbTBQv0-onTukNdr-KlQheMM1NEFkuA", authDomain: "dgss-58aec.firebaseapp.com", projectId: "dgss-58aec", storageBucket: "dgss-58aec.firebasestorage.app", messagingSenderId: "879356370168", appId: "1:879356370168:web:d5aab39fede28db175ef0d" };

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
export const appId = "seafood-store-real";

export const COLLECTIONS = {
    CONFIG: 'storeConfig',
    PRODUCTS: 'products',
    ORDERS: 'orders',
    INQUIRIES: 'inquiries',
    NOTICES: 'notices',
    BLOGS: 'blogs',
    COMMENTS: 'blogComments'
};

// 자주 쓰는 레퍼런스 헬퍼
export const getPublicDataRef = (col) => collection(db, "artifacts", appId, "public", "data", col);
export const getConfDoc = () => doc(db, "artifacts", appId, "public", "data", COLLECTIONS.CONFIG, "main");